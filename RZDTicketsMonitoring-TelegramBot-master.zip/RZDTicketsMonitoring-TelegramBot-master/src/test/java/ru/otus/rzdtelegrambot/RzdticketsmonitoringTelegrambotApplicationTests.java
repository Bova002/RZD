package ru.otus.rzdtelegrambot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RzdticketsmonitoringTelegrambotApplicationTests {

    @Test
    void contextLoads() {
    }

}
